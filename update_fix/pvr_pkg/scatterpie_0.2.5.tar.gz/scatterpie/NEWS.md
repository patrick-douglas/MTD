# scatterpie 0.2.5

+ S3 method consistency with ggplot2 (v=4.0.0) (2025-06-21, Sat, #50)

# scatterpie 0.2.4

+ if `geom_scatterpie(data = NULL)`, the layer will try to use `plot$data` (2024-08-28, Wed)

# scatterpie 0.2.3

+ supports labeling slices of pies (2024-06-05, Wed, #49)

# scatterpie 0.2.2

+ introduce donut_radius and bg_circle_radius parameters to control the layer of pie (2024-04-03, Wed, #46)

# scatterpie 0.2.1

+ introduce `breaks` parameter in `geom_scatterpie_legend()` (2023-06-07, Wed, #40)

# scatterpie 0.2.0

+ increase R version of dependency to 4.1.0 as we used native pipe (2023-04-26, Wed)

# scatterpie 0.1.9

+ allow label customization in scatterpie legend (2023-04-22, Sat, #38)
+ fixed the overlap issue with group mapping (2023-03-02, Thu, #37)

# scatterpie 0.1.8

+ improve the legend of pie radius (2022-09-03, Sat, #35)

# scatterpie 0.1.7

+ import `get_aes_var` from ggfun instead of rvcheck (2021-08-20)

# scatterpie 0.1.6

+ fixed R check by suggesting rmarkdown package

