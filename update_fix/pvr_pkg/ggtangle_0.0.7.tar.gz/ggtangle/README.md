# ggtangle: Draw Network with Data

‘ggtangle’ extends the ‘ggplot2’ plotting system to support network
visualization. ‘ggtangle’ is inspired by ‘ggtree’ and aims to work with
network associated data.

## :writing_hand: Authors

Guangchuang YU

School of Basic Medical Sciences, Southern Medical University

<https://yulab-smu.top>
