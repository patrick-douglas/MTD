## rtf R Package

An R package to produce RTF documents.

### Installation
From CRAN:

```
install.packages("rtf")
```

or from github:
```
library(devtools)
install_github("schaffman5/rtf")
```


### Usage
See the vignette for usage details: https://cran.r-project.org/web/packages/rtf/index.html

```
vignette("rtf")
```
