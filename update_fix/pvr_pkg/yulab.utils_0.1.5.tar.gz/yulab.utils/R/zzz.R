##' @importFrom memoise memoise
.onLoad <- function(libname, pkgname) { 
    yread <<- memoise::memoise(yread)
    yread_tsv <<- memoise::memoise(yread_tsv) 
}




