library(testthat)
library(mockery)
library(biomaRt)
library(httptest2)

test_check("biomaRt", encoding = "UTF-8")