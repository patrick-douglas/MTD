## ----echo=FALSE---------------------------------------------------------------
library(knitr)
opts_chunk$set(message = FALSE, warning = FALSE, fig.height= 3, fig.width= 5)

