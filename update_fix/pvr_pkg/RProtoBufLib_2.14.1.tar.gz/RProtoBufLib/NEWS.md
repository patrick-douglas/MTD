CHANGES IN VERSION 2.0.0
----------------------------------

+ update protobuf to 3.10


CHANGES IN VERSION 1.99.0
-------------------------

+  bundle the protobuf c++ library and expose its headers and static libraries
