BiocGenerics:::testPackage("graph", pattern="_test.R")
