##' @importFrom enrichplot cnetplot
##' @export
enrichplot::cnetplot

##' @importFrom enrichplot dotplot
##' @export
enrichplot::dotplot

##' @importFrom enrichplot emapplot
##' @export
enrichplot::emapplot


##' @importFrom enrichplot goplot
##' @export
enrichplot::goplot

##' @importFrom enrichplot gseaplot
##' @export
enrichplot::gseaplot

##' @importFrom enrichplot heatplot
##' @export
enrichplot::heatplot

##' @importFrom enrichplot ridgeplot
##' @export
enrichplot::ridgeplot
