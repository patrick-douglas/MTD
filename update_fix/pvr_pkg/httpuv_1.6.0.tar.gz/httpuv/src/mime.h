#include <string>

// Given a file extension, get the corresponding mime type
std::string find_mime_type(const std::string& ext);
