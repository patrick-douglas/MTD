GENOME <- "wuhCor1"
ORGANISM <- "Betacoronavirus"
ASSEMBLED_MOLECULES <- "NC_045512v2"
CIRC_SEQS <- character(0)

NCBI_LINKER <- list(
    assembly_accession="GCA_009858895.3"
)

