# can construct and print

    Code
      in_schema("schema", "table")
    Output
      <SCHEMA> `schema`.`table`

---

    Code
      in_catalog("catalog", "schema", "table")
    Output
      <CATALOG> `catalog`.`schema`.`table`

