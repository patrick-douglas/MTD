# sql tbl can be printed

    Code
      mf2
    Output
      # Source:   SQL [3 x 2]
      # Database: sqlite ?.?.? [:memory:]
            x     y
        <int> <int>
      1     1     3
      2     2     2
      3     3     1

